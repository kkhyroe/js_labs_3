var arr = [0, -11, 11, 1, 12, 2, 0.1, 1.1, 22, 3, 100];
console.log(arr.sort((a, b) => b - a));